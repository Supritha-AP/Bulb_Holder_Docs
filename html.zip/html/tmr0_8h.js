var tmr0_8h =
[
    [ "get_TIMER0Status", "tmr0_8h.html#a3090c3e2bcc310ef2111cd0db99090c3", null ],
    [ "TMR0_DefaultInterruptHandler", "tmr0_8h.html#aab6153f25bf68ecb07d33a269e5b8dc4", null ],
    [ "TMR0_Initialize", "tmr0_8h.html#a73398a18b711af030af4db3c4c6c15e1", null ],
    [ "TMR0_ISR", "tmr0_8h.html#a8a465e070e24fe06a488f952b089886d", null ],
    [ "TMR0_ReadTimer", "tmr0_8h.html#a091fd68f48dfccc6890ab47872b0e551", null ],
    [ "TMR0_Reload", "tmr0_8h.html#a61659c2dc0ff29595abe23b24cf81d14", null ],
    [ "TMR0_SetInterruptHandler", "tmr0_8h.html#a1b6adc623040b0e791871a0f9652a67f", null ],
    [ "TMR0_WriteTimer", "tmr0_8h.html#a951111850fea5583b9f98b566b2e4508", null ],
    [ "TMR0_InterruptHandler", "tmr0_8h.html#a809211677d0753d6397e04afdbb945a3", null ]
];