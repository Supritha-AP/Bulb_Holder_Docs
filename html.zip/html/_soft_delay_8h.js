var _soft_delay_8h =
[
    [ "get_Delay_Start_vr", "_soft_delay_8h.html#a17486cb895bab505bb84d9c1de58f733", null ],
    [ "get_Delay_Time", "_soft_delay_8h.html#afc305bf91915c1a4a4484ab843f652fb", null ]
];