var tmr0_8c =
[
    [ "get_TIMER0Status", "tmr0_8c.html#a3090c3e2bcc310ef2111cd0db99090c3", null ],
    [ "TMR0_Initialize", "tmr0_8c.html#a73398a18b711af030af4db3c4c6c15e1", null ],
    [ "TMR0_ISR", "tmr0_8c.html#a8a465e070e24fe06a488f952b089886d", null ],
    [ "TMR0_ReadTimer", "tmr0_8c.html#a091fd68f48dfccc6890ab47872b0e551", null ],
    [ "TMR0_Reload", "tmr0_8c.html#a61659c2dc0ff29595abe23b24cf81d14", null ],
    [ "TMR0_WriteTimer", "tmr0_8c.html#a951111850fea5583b9f98b566b2e4508", null ],
    [ "timer0ReloadVal", "tmr0_8c.html#aee53ca6ad8ef9a518fdc9a0a8af1fe91", null ],
    [ "V_COUNTER_1ms", "tmr0_8c.html#a1a08a465823afecd9ccddf909acf1fc5", null ]
];