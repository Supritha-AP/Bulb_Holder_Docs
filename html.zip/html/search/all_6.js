var searchData=
[
  ['get_5fdelay_5fstart_5fvr_0',['get_Delay_Start_vr',['../_soft_delay_8c.html#a17486cb895bab505bb84d9c1de58f733',1,'get_Delay_Start_vr(uint32_t *Start_vr_reset_u32r):&#160;SoftDelay.c'],['../_soft_delay_8h.html#a17486cb895bab505bb84d9c1de58f733',1,'get_Delay_Start_vr(uint32_t *Start_vr_reset_u32r):&#160;SoftDelay.c']]],
  ['get_5fdelay_5ftime_1',['get_Delay_Time',['../_soft_delay_8c.html#afc305bf91915c1a4a4484ab843f652fb',1,'get_Delay_Time(uint32_t *v_Timer_StartingValue_u32r):&#160;SoftDelay.c'],['../_soft_delay_8h.html#afc305bf91915c1a4a4484ab843f652fb',1,'get_Delay_Time(uint32_t *v_Timer_StartingValue_u32r):&#160;SoftDelay.c']]],
  ['get_5fdelaystatus_2',['get_DelayStatus',['../main_8c.html#aab46d330a44aa497c2e62f09eea9c9de',1,'get_DelayStatus(uint32_t *v_TimerStartingValue_u32r, uint16_t v_TimeDelay_u8r):&#160;SoftDelay.c'],['../_soft_delay_8c.html#a205d3aacf8e8595578f1d64fd317a10c',1,'get_DelayStatus(uint32_t *v_TimerStartingValue_u32r, uint16_t v_TimeDelay_u16r):&#160;SoftDelay.c']]],
  ['get_5ftimer0status_3',['get_TIMER0Status',['../tmr0_8c.html#a3090c3e2bcc310ef2111cd0db99090c3',1,'get_TIMER0Status(void):&#160;tmr0.c'],['../tmr0_8h.html#a3090c3e2bcc310ef2111cd0db99090c3',1,'get_TIMER0Status(void):&#160;tmr0.c']]]
];
