var searchData=
[
  ['off_0',['OFF',['../main_8c.html#a29e413f6725b2ba32d165ffaa35b01e5',1,'main.c']]],
  ['old_5flight_5fstatus_1',['old_light_status',['../main_8c.html#ae6780bda8f0b5a73edacc1f8318c47d4',1,'main.c']]],
  ['on_2',['ON',['../main_8c.html#ad76d1750a6cdeebd506bfcd6752554d2',1,'main.c']]],
  ['oscillator_5finitialize_3',['OSCILLATOR_Initialize',['../mcc_8c.html#a4777dd92514a7e4ef803f9e869006f5d',1,'OSCILLATOR_Initialize(void):&#160;mcc.c'],['../mcc_8h.html#a4777dd92514a7e4ef803f9e869006f5d',1,'OSCILLATOR_Initialize(void):&#160;mcc.c']]],
  ['output_4',['OUTPUT',['../pin__manager_8h.html#a61a3c9a18380aafb6e430e79bf596557',1,'pin_manager.h']]]
];
