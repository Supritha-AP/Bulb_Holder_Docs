var searchData=
[
  ['off_0',['OFF',['../main_8c.html#a29e413f6725b2ba32d165ffaa35b01e5',1,'main.c']]],
  ['on_1',['ON',['../main_8c.html#ad76d1750a6cdeebd506bfcd6752554d2',1,'main.c']]],
  ['output_2',['OUTPUT',['../pin__manager_8h.html#a61a3c9a18380aafb6e430e79bf596557',1,'pin_manager.h']]]
];
