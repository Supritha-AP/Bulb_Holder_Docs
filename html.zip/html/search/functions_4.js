var searchData=
[
  ['light_5ftrigger_0',['LIGHT_Trigger',['../main_8c.html#a0ba4ceac65f1e64308ec2932ec40ab95',1,'main.c']]]
];
