var _soft_delay_8c =
[
    [ "get_Delay_Start_vr", "_soft_delay_8c.html#a17486cb895bab505bb84d9c1de58f733", null ],
    [ "get_Delay_Time", "_soft_delay_8c.html#afc305bf91915c1a4a4484ab843f652fb", null ],
    [ "get_DelayStatus", "_soft_delay_8c.html#a205d3aacf8e8595578f1d64fd317a10c", null ]
];