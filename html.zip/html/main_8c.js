var main_8c =
[
    [ "failed", "main_8c.html#a329e5e6be8249786438bb196e1383a0b", null ],
    [ "LIGHT", "main_8c.html#abc98e3adbe205cd3ab83d97150d0a845", null ],
    [ "LIGHT_ADDR", "main_8c.html#a2ac1722d2b2411a7e4e8ddbc1e69f32f", null ],
    [ "MIN_RX_FREEQUENCY", "main_8c.html#adf98def783ed54c623b03d104c302a21", null ],
    [ "OFF", "main_8c.html#a29e413f6725b2ba32d165ffaa35b01e5", null ],
    [ "ON", "main_8c.html#ad76d1750a6cdeebd506bfcd6752554d2", null ],
    [ "passed", "main_8c.html#aecb4c8a9311ab20624a07e66011c88a4", null ],
    [ "get_DelayStatus", "main_8c.html#aab46d330a44aa497c2e62f09eea9c9de", null ],
    [ "LIGHT_Trigger", "main_8c.html#a0ba4ceac65f1e64308ec2932ec40ab95", null ],
    [ "main", "main_8c.html#a6288eba0f8e8ad3ab1544ad731eb7667", null ],
    [ "old_light_status", "main_8c.html#ae6780bda8f0b5a73edacc1f8318c47d4", null ],
    [ "Sensing_Receiver", "main_8c.html#a76c479def9fb7a54844ac00d804bded2", null ],
    [ "Sensing_Validation", "main_8c.html#aab1f0aa6d04b71bf74edbc5ab5cb8a2a", null ],
    [ "Flag_FreCounter", "main_8c.html#aa50dcc925c0677206a7ec31ae5876cf3", null ],
    [ "time_EEPROM_WRITE_count", "main_8c.html#ac4b0b98f3793da157b20c3b787ac2724", null ],
    [ "time_EEPROM_WRITE_Period", "main_8c.html#a73a135e15d1e62cef85d7a922599d051", null ],
    [ "time_Scanning_Period", "main_8c.html#aa4eb53e7ea76b82e70e6271e24ee3c9f", null ],
    [ "time_Scanning_Period_count", "main_8c.html#a393cfcc8842fb5ad826f7d77d596fb00", null ],
    [ "V_Freequency_u32", "main_8c.html#a8a7739f4b94aad707edf65621fc287f0", null ],
    [ "V_FreequencyCounter_u32", "main_8c.html#a8968adb0d909e10cc85e8f457c7e2187", null ]
];