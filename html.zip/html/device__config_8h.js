var device__config_8h =
[
    [ "_XTAL_FREQ", "device__config_8h.html#a024148e99a7143db044a48216664d03d", null ]
];